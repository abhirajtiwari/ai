i=213
for fi in *.jpg; do
    mv "$fi" $i.jpg
    i=$((i+1))
done
