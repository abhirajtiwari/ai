i=217
for fi in *.jpg; do
    mv "$fi" $i.jpg
    i=$((i+1))
done
